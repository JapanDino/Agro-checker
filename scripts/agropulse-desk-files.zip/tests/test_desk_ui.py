"""Static checks for the desktop workspace /scouting/desk. No model, archive or journal writes."""
import re
import threading
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.request import Request, urlopen

from agro_checker.pipeline import ROOT
from agro_checker.scouting_server import make_server

WEB = ROOT / 'web/scouting'


class DeskUiTest(unittest.TestCase):
    def test_every_script_id_exists_in_markup(self):
        html = (WEB / 'desk.html').read_text(encoding='utf-8')
        js = (WEB / 'desk.js').read_text(encoding='utf-8')
        ids = set(re.findall(r'\bid="([^"]+)"', html))
        used = set(re.findall(r"\$\('([a-z0-9-]+)'\)", js))
        created = {'swipe-toggle-back'}
        self.assertFalse(used - ids - created, used - ids - created)

    def test_csp_friendly_and_offline(self):
        for name in ['desk.html', 'desk.js', 'desk.css', 'desk-theme.js']:
            text = (WEB / name).read_text(encoding='utf-8')
            self.assertNotRegex(text, r'https?://(?!www\.w3\.org)', name)
            if name != 'desk.js':  # desk.js builds a downloadable plan sheet with its own <style>
                self.assertNotIn('<style', text, name)
            self.assertNotRegex(text, r'\sstyle="', name)
            self.assertNotIn("setAttribute('style'", text, name)
        html = (WEB / 'desk.html').read_text(encoding='utf-8')
        self.assertNotRegex(html, r'<script(?![^>]*\bsrc=)[^>]*>', 'inline script')

    def test_no_invented_outcomes_or_probabilities(self):
        js = (WEB / 'desk.js').read_text(encoding='utf-8')
        self.assertNotRegex(js, r'вероятност|диагноз болезни|урожайност')
        self.assertIn("real_visit_confirmed: true", js)
        self.assertIn("relative: null", js)  # reference point is explicit, never a client-made place id

    def test_server_serves_desk_with_csp(self):
        with TemporaryDirectory() as folder:
            server = make_server(Path(folder), 0)
            threading.Thread(target=server.serve_forever, daemon=True).start()
            try:
                port = server.server_port
                for path, kind in [('/scouting/desk', 'text/html'), ('/scouting/desk.js', 'text/javascript'),
                                   ('/scouting/desk.css', 'text/css'), ('/scouting/desk-theme.js', 'text/javascript'),
                                   ('/scouting/assets/fonts/Montserrat-VF.woff', 'font/woff')]:
                    with urlopen(Request(f'http://127.0.0.1:{port}{path}', headers={'Host': f'127.0.0.1:{port}'})) as r:
                        self.assertEqual(r.status, 200)
                        self.assertTrue(r.headers['Content-Type'].startswith(kind), path)
                        self.assertIn("script-src 'self'", r.headers['Content-Security-Policy'])
            finally:
                server.shutdown(); server.server_close()


if __name__ == '__main__':
    unittest.main()
