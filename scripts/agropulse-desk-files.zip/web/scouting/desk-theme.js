/* Applies the saved appearance before first paint. Appearance never changes journal data. */
(() => {
  'use strict';
  let theme = 'light';
  try { const saved = localStorage.getItem('agropulse:desk-theme:v1'); if (saved === 'contrast') theme = 'contrast'; } catch {}
  document.documentElement.dataset.theme = theme;
})();
