/* AgroPulse · Onlyfarms desktop workspace.
   Reads only the existing /api/scouting routes of this branch. Never computes satellite metrics
   in the browser, never invents visits, photos, crops or probabilities. */
'use strict';
(async () => {
  const $ = id => document.getElementById(id);
  const NS = 'http://www.w3.org/2000/svg';
  const TZ = 'Europe/Moscow';
  const THRESHOLD = 0.05; // same ±0,05 split the existing map legend uses for area colours
  const PERIOD_LABEL = {recent2026: 'Июль–октябрь 2026', spring2024: 'Весна 2024'};
  const STATUS = {
    inspect: {label: 'Осмотреть первым', short: 'Осмотреть', icon: 'i-alert', cls: 'st-inspect', map: '#E5484D'},
    check: {label: 'Проверить', short: 'Проверить', icon: 'i-clock', cls: 'st-check', map: '#F2B53B'},
    stable: {label: 'Без изменений', short: 'Без изменений', icon: 'i-check', cls: 'st-stable', map: '#3BAA6B'},
    nodata: {label: 'Нет данных', short: 'Нет данных', icon: 'i-nodata', cls: 'st-nodata', map: '#9AA39E'}
  };
  const ORDER = ['inspect', 'check', 'stable', 'nodata'];
  const OUTCOME = {
    nothing_notable: {label: 'Без замечаний', cls: 'st-stable', icon: 'i-check'},
    observed_change: {label: 'Есть изменение', cls: 'st-check', icon: 'i-alert'},
    unclear: {label: 'Неясно', cls: 'st-nodata', icon: 'i-help'},
    not_checked: {label: 'Не удалось осмотреть', cls: 'st-nodata', icon: 'i-nodata'}
  };
  const RAMPS = {
    ndvi: [['rgb(40,113,78)', 'Высокая, ≈ +1'], ['rgb(231,217,153)', 'Средняя, ≈ 0'], ['rgb(163,122,79)', 'Низкая, ≈ −1']],
    ndmi: [['rgb(42,121,139)', 'Высокая, ≈ +1'], ['rgb(223,224,198)', 'Средняя, ≈ 0'], ['rgb(182,145,103)', 'Низкая, ≈ −1']]
  };
  const KEYS = {actor: 'agropulse:desk-actor:v1', theme: 'agropulse:desk-theme:v1', help: 'agropulse:desk-map-help:v1'};

  const S = {
    data: null, bundle: null, period: 'recent2026', view: 'today', fid: 'R11', metric: 'ndvi',
    pairs: {}, ws: {}, areas: new Map(), filter: 'all', sort: 'queue',
    detail: null, place: null, placeSource: null, relative: null, placeConfirmed: false, swipe: false,
    taskRequest: uid(), taskBusy: false, seasonFid: 'R11', seasonMetric: 'ndvi', seasonScene: null, seasonRequest: uid(),
    trip: {order: [], focus: null, request: uid(), report: null, busy: false},
    visit: {request: uid(), photos: [], busy: false, drafts: new Map(), task: ''}, focusPin: null
  };
  const runs = {area: 0, place: 0, ws: 0, season: 0, history: 0, report: 0};

  // ---------- helpers ----------
  function uid() { return crypto.randomUUID().replaceAll('-', ''); }
  function el(tag, attrs = {}, ...kids) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'text') n.textContent = v; else if (k === 'class') n.className = v; else n.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) if (kid !== undefined && kid !== null && kid !== false) n.append(kid);
    return n;
  }
  function svgEl(tag, attrs = {}, parent) {
    const n = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
    if (parent) parent.append(n);
    return n;
  }
  function icon(id, cls) { const s = svgEl('svg', cls ? {class: cls, 'aria-hidden': 'true'} : {'aria-hidden': 'true'}); svgEl('use', {href: '#' + id}, s); return s; }
  const isNum = v => typeof v === 'number' && Number.isFinite(v);
  const num = (v, d = 3) => isNum(v) ? v.toFixed(d).replace('.', ',').replace('-', '−') : '—';
  const signed = (v, d = 3) => isNum(v) ? (v > 0 ? '+' : '') + num(v, d) : 'нет данных';
  const pct = v => isNum(v) ? Math.round(v * 100) + '%' : '—';
  const day = v => new Date(v).toLocaleDateString('ru-RU', {timeZone: TZ});
  const dayShort = v => new Date(v).toLocaleDateString('ru-RU', {timeZone: TZ, day: '2-digit', month: '2-digit'});
  const dayLong = v => new Date(v).toLocaleDateString('ru-RU', {timeZone: TZ, day: 'numeric', month: 'long', year: 'numeric'});
  const dateTime = v => new Date(v).toLocaleString('ru-RU', {timeZone: TZ, dateStyle: 'medium', timeStyle: 'short'});
  const plural = (n, one, few, many) => { const r = n % 100, d = n % 10; return r >= 11 && r <= 14 ? many : d === 1 ? one : d >= 2 && d <= 4 ? few : many; };
  const days = v => { const n = Math.round(v); return n + ' ' + plural(n, 'день', 'дня', 'дней'); };
  const initials = name => String(name || '').trim().split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('') || '··';
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); return true; } catch { return false; } }
  };
  const defaultActor = () => store.get(KEYS.actor) || '';

  async function api(path, body) {
    const init = body === undefined ? {} : {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Field-Token': S.data.token}, body: JSON.stringify(body)};
    const response = await fetch(path, init);
    let data;
    try { data = await response.json(); } catch { throw new Error('Сервер вернул непонятный ответ'); }
    if (!response.ok) throw new Error(data.error || 'Не удалось выполнить запрос');
    return data;
  }
  const q = obj => new URLSearchParams(obj).toString();

  let toastTimer = 0;
  function toast(text, {error = false, action, onAction, ms = 6000} = {}) {
    clearTimeout(toastTimer);
    $('toast-text').textContent = text;
    $('toast').classList.toggle('error', error);
    $('toast').setAttribute('role', error ? 'alert' : 'status');
    const b = $('toast-action');
    b.hidden = !action; b.textContent = action || '';
    b.onclick = () => { $('toast').hidden = true; onAction?.(); };
    $('toast').hidden = false;
    toastTimer = setTimeout(() => { $('toast').hidden = true; }, ms);
  }
  $('toast-close').addEventListener('click', () => { $('toast').hidden = true; });

  // ---------- status classification (describes the observed archive change only) ----------
  function classify(row) {
    if (!row || row.status !== 'ready') return 'nodata';
    const v = row.ndvi?.base, m = row.ndmi?.base;
    const dv = isNum(v) && v <= -THRESHOLD, dm = isNum(m) && m <= -THRESHOLD;
    if (dv && dm) return 'inspect';
    if (dv || dm) return 'check';
    return 'stable';
  }
  function worst(row) { const vals = [row?.ndvi?.base, row?.ndmi?.base].filter(isNum); return vals.length ? Math.min(...vals) : Infinity; }
  function badge(status, text) {
    const s = STATUS[status];
    return el('span', {class: 'status-badge ' + s.cls}, icon(s.icon), el('span', {text: text || s.label}));
  }
  function headline(row, status, pairDays) {
    const span = pairDays ? ' за ' + days(pairDays) : '';
    if (status === 'nodata') return row?.reason || 'Нет пригодной общей пары снимков';
    const dv = row.ndvi.base <= -THRESHOLD, dm = row.ndmi.base <= -THRESHOLD;
    if (dv && dm) return 'Зелёная масса и влажность покрова снизились' + span;
    if (dm) return 'Индекс влажности покрова снизился' + span;
    if (dv) return 'Индекс зелёной массы снизился' + span;
    if (row.ndvi.base >= THRESHOLD || row.ndmi.base >= THRESHOLD) return 'Снижения нет, индексы выросли' + span;
    return 'Заметных изменений индексов нет' + span;
  }
  function robustText(row) {
    if (!row || row.status !== 'ready') return '';
    const both = row.ndvi.robust && row.ndmi.robust;
    return both ? 'устойчиво к смещению обводки' : 'чувствительно к положению границ';
  }

  // ---------- basemap thumbnails (aerial mosaic crop + dashed approximate outline) ----------
  const basemapSize = await new Promise(resolve => {
    const img = new Image();
    img.onload = () => resolve([img.naturalWidth, img.naturalHeight]);
    img.onerror = () => resolve([2300, 2800]);
    img.src = '/scouting/assets/basemap.jpg';
  });
  const merc = lat => Math.log(Math.tan(Math.PI / 4 + lat * Math.PI / 360));
  function project(lon, lat) {
    const [[s, w], [n, e]] = S.bundle.basemap.bounds;
    return [(lon - w) / (e - w) * basemapSize[0], (merc(n) - merc(lat)) / (merc(n) - merc(s)) * basemapSize[1]];
  }
  function ring(fid) {
    const f = S.bundle.geometry.features.find(x => x.properties.id === fid);
    return f ? f.geometry.coordinates[0] : [];
  }
  function thumb(fid, chip = true) {
    const box = el('div', {class: 'thumb', role: 'img', 'aria-label': 'Спутниковая подложка площади ' + fid + ', приблизительная обводка'});
    const draw = () => {
      const cw = box.clientWidth || 280, ch = box.clientHeight || 170, pad = 18;
      const pts = ring(fid).map(([lon, lat]) => project(lon, lat));
      if (!pts.length) return;
      const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
      const bw = Math.max(...xs) - Math.min(...xs), bh = Math.max(...ys) - Math.min(...ys);
      const k = Math.min((cw - pad * 2) / bw, (ch - pad * 2 - (chip ? 26 : 0)) / bh);
      const ox = (cw - bw * k) / 2 - Math.min(...xs) * k, oy = (ch - bh * k - (chip ? 26 : 0)) / 2 - Math.min(...ys) * k;
      box.style.backgroundSize = (basemapSize[0] * k) + 'px ' + (basemapSize[1] * k) + 'px';
      box.style.backgroundPosition = ox + 'px ' + oy + 'px';
      box.querySelector('svg.outline')?.remove();
      const s = svgEl('svg', {class: 'outline', viewBox: `0 0 ${cw} ${ch}`, 'aria-hidden': 'true'});
      svgEl('polygon', {points: pts.map(p => (p[0] * k + ox).toFixed(1) + ',' + (p[1] * k + oy).toFixed(1)).join(' ')}, s);
      box.prepend(s);
    };
    if (chip) box.append(el('span', {class: 'thumb-chip'}, icon('i-info'), 'Приблизительные границы'));
    new ResizeObserver(draw).observe(box);
    return box;
  }

  // ---------- data loading ----------
  async function loadWorkspace(period, pair) {
    const key = period + '|' + (pair ? pair.before + '|' + pair.after : 'default');
    if (S.ws[key]) return S.ws[key];
    const params = pair ? {period, before: pair.before, after: pair.after} : {period};
    const ws = await api('/api/scouting/workspace?' + q(params));
    S.ws[key] = ws;
    if (!pair && ws.pair) S.ws[period + '|' + ws.pair.before.id + '|' + ws.pair.after.id] = ws;
    return ws;
  }
  function currentWs(period = S.period) {
    const p = S.pairs[period];
    return p ? S.ws[period + '|' + p.before + '|' + p.after] : S.ws[period + '|default'];
  }
  async function ensurePeriod(period) {
    if (!S.pairs[period]) {
      const ws = await loadWorkspace(period);
      if (ws.pair) S.pairs[period] = {before: ws.pair.before.id, after: ws.pair.after.id};
    }
    return currentWs(period);
  }
  async function loadArea(fid, period) {
    const p = S.pairs[period];
    if (!p) return null;
    const key = [fid, period, p.before, p.after].join('|');
    if (!S.areas.has(key)) S.areas.set(key, api('/api/scouting/area?' + q({fid, period, before: p.before, after: p.after})).catch(e => { S.areas.delete(key); throw e; }));
    return S.areas.get(key);
  }
  async function refreshState() {
    const fresh = await api('/api/scouting/state');
    S.data = fresh;
    renderActors();
    return fresh;
  }

  // ---------- theme with rollback ----------
  function applyTheme(theme, persist) {
    document.documentElement.dataset.theme = theme;
    for (const b of document.querySelectorAll('[data-theme-choice]')) b.setAttribute('aria-pressed', String(b.dataset.themeChoice === theme));
    if (persist) store.set(KEYS.theme, theme);
  }
  applyTheme(document.documentElement.dataset.theme === 'contrast' ? 'contrast' : 'light', false);
  for (const b of document.querySelectorAll('[data-theme-choice]')) b.addEventListener('click', () => {
    const prev = document.documentElement.dataset.theme, next = b.dataset.themeChoice;
    if (prev === next) return;
    applyTheme(next, true);
    toast(next === 'contrast' ? 'Включено контрастное оформление для работы на солнце.' : 'Включено светлое оформление.', {action: 'Вернуть как было', onAction: () => applyTheme(prev, true), ms: 9000});
  });

  // ---------- top bar ----------
  $('farm-button').addEventListener('click', () => {
    const open = $('farm-menu').hidden; $('farm-menu').hidden = !open; $('farm-button').setAttribute('aria-expanded', String(open));
  });
  document.addEventListener('click', e => { if (!e.target.closest('.farm-switch')) { $('farm-menu').hidden = true; $('farm-button').setAttribute('aria-expanded', 'false'); } });
  function renderAvatar() {
    const a = defaultActor();
    const target = $('avatar-initials'); target.replaceChildren();
    if (a) target.textContent = initials(a); else target.append(icon('i-user'));
    $('avatar').title = a ? 'Ответственный по умолчанию: ' + a : 'Указать ответственного по умолчанию';
    $('avatar').setAttribute('aria-label', $('avatar').title);
  }
  function openSettings() {
    $('default-actor').value = defaultActor();
    $('version-line').textContent = S.data ? 'Версия архива ' + S.data.version.slice(0, 12) + ' · протокол от ' + day(S.data.snapshot_at) + '. Обучение модели и автоматические диагнозы выключены.' : '';
    $('settings').showModal();
  }
  $('avatar').addEventListener('click', openSettings);
  $('open-settings').addEventListener('click', openSettings);
  $('settings').addEventListener('close', () => {
    if ($('settings').returnValue !== 'save') return;
    store.set(KEYS.actor, $('default-actor').value.trim().slice(0, 120));
    renderAvatar(); fillActorDefaults();
  });
  $('reset-hints').addEventListener('click', () => { store.set(KEYS.help, ''); toast('Подсказка карты появится при следующем открытии карты.'); });
  function renderActors() {
    const names = new Set();
    for (const t of S.data?.tasks || []) names.add(t.payload.actor);
    for (const v of S.data?.visits || []) names.add(v.payload.actor);
    if (defaultActor()) names.add(defaultActor());
    $('actors').replaceChildren(...[...names].map(n => el('option', {value: n})));
  }
  function fillActorDefaults() {
    for (const id of ['task-actor', 'season-actor', 'visit-actor']) if (!$(id).value) $(id).value = defaultActor();
    taskReady(); seasonReady(); visitReady();
  }

  // ---------- routing ----------
  const VIEWS = ['today', 'map', 'season', 'trip', 'journal'];
  const TITLES = {today: 'Сегодня', map: 'Карта', season: 'Сезон', trip: 'Выезд', journal: 'Журнал'};
  function route() {
    const [path, query] = location.hash.slice(1).split('?');
    const view = VIEWS.includes(path) ? path : 'today';
    const params = new URLSearchParams(query || '');
    const area = params.get('area');
    if (area && /^R\d{2}$/.test(area) && S.bundle?.features?.[area]) { if (view === 'season') S.seasonFid = area; else S.fid = area; }
    show(view);
  }
  function go(view, params) { const hash = '#' + view + (params ? '?' + q(params) : ''); if (location.hash === hash) route(); else location.hash = hash; }
  async function show(view) {
    S.view = view;
    for (const v of document.querySelectorAll('[data-view]')) v.hidden = v.dataset.view !== view;
    for (const a of document.querySelectorAll('[data-view-link]')) { if (a.dataset.viewLink === view) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); }
    document.title = 'AgroPulse · ' + TITLES[view];
    window.scrollTo(0, 0);
    try {
      if (view === 'today') await renderToday();
      if (view === 'map') await openMap();
      if (view === 'season') await renderSeason();
      if (view === 'trip') renderTrip();
      if (view === 'journal') renderJournal();
    } catch (error) { toast(error.message, {error: true}); }
  }

  // ---------- period switches ----------
  function paintPeriodSwitches() {
    for (const b of document.querySelectorAll('[data-period]')) b.setAttribute('aria-pressed', String(b.dataset.period === S.period));
  }
  for (const b of document.querySelectorAll('[data-period]')) b.addEventListener('click', async () => {
    if (S.period === b.dataset.period) return;
    S.period = b.dataset.period; paintPeriodSwitches(); resetPlace();
    await show(S.view);
  });

  // ================= TODAY =================
  function rowsSorted(ws) {
    const rows = (ws?.rows || []).map(r => ({...r, st: classify(r)}));
    if (S.sort === 'code') rows.sort((a, b) => a.id.localeCompare(b.id));
    else if (S.sort === 'coverage') rows.sort((a, b) => (b.coverage ?? -1) - (a.coverage ?? -1) || a.id.localeCompare(b.id));
    else rows.sort((a, b) => ORDER.indexOf(a.st) - ORDER.indexOf(b.st) || worst(a) - worst(b) || a.id.localeCompare(b.id));
    return rows;
  }
  async function renderToday() {
    paintPeriodSwitches();
    $('today-date').textContent = dayLong(new Date());
    $('today-data-line').textContent = 'Рассчитываем общую пару снимков…';
    $('queue').replaceChildren(el('p', {class: 'empty-queue', text: 'Открываем сводки площадей…'}));
    renderTodaySide();
    const run = ++runs.ws;
    const ws = await ensurePeriod(S.period);
    if (run !== runs.ws) return;
    if (!ws?.pair) {
      $('today-data-line').textContent = 'Для периода «' + PERIOD_LABEL[S.period] + '» нет общей пары снимков.';
      $('counters').replaceChildren(); $('queue').replaceChildren(el('p', {class: 'card empty-queue', text: 'Нет пригодной общей пары дат. Другие даты не подставляются.'}));
      return;
    }
    $('today-data-line').textContent = `Последний снимок пары: ${day(ws.pair.after.at)} • Sentinel-2 L2A • сравнение с ${day(ws.pair.before.at)} (${days(ws.pair.days)}) • пригодны ${ws.available_areas}/${ws.total_areas} площадей`;
    const rows = rowsSorted(ws);
    const counts = Object.fromEntries(ORDER.map(k => [k, rows.filter(r => r.st === k).length]));
    const map = {inspect: 'inspect', check: 'check', stable: 'stable', nodata: 'nodata'};
    $('counters').replaceChildren(...ORDER.map(k => {
      const b = el('button', {type: 'button', class: 'counter ' + STATUS[k].cls, 'aria-pressed': String(S.filter === map[k]), 'aria-label': `${STATUS[k].short}: ${counts[k]}. Показать только эти площади`},
        icon(STATUS[k].icon), el('span', {}, el('b', {text: String(counts[k])}), el('span', {text: STATUS[k].short})));
      b.addEventListener('click', () => setFilter(S.filter === k ? 'all' : k));
      return b;
    }));
    $('queue-rule').textContent = `Как построена очередь: «Осмотреть первым» — NDVI и NDMI площади снизились больше чем на ${num(THRESHOLD, 2)}; «Проверить» — снизился один индекс; «Без изменений» — снижения больше ${num(THRESHOLD, 2)} нет; «Нет данных» — нет пригодной общей пары. Это описание архивного спутникового изменения, а не прогноз болезни и не проверенная модель приоритета.`;
    for (const b of document.querySelectorAll('#queue-filter [data-filter]')) b.setAttribute('aria-pressed', String(b.dataset.filter === S.filter));
    const visible = rows.filter(r => S.filter === 'all' || r.st === S.filter);
    const list = visible.map((r, i) => fieldCard(r, ws, i === 0 && S.sort === 'queue' && S.filter !== 'nodata' && r.st !== 'nodata'));
    $('queue').replaceChildren(...(list.length ? list : [el('p', {class: 'card empty-queue', text: 'В этой группе площадей нет.'})]));
    renderTodaySide();
  }
  function fieldCard(r, ws, primary) {
    const card = el('article', {class: 'card field-card', 'aria-labelledby': 'fc-' + r.id});
    const left = el('div', {});
    left.append(el('div', {class: 'fc-head'}, el('span', {class: 'fc-code', id: 'fc-' + r.id, text: r.id}), badge(r.st)));
    left.append(el('p', {class: 'fc-title', text: headline(r, r.st, ws.pair.days)}));
    const meta = el('ul', {class: 'meta'});
    if (r.status === 'ready') meta.append(el('li', {}, icon('i-layers'), el('span', {text: `ΔNDVI ${signed(r.ndvi.base)} • ΔNDMI ${signed(r.ndmi.base)} • ${robustText(r)}`})));
    meta.append(el('li', {}, icon('i-cal'), el('span', {text: `Снимки: ${day(ws.pair.before.at)} → ${day(ws.pair.after.at)}`})));
    meta.append(el('li', {}, icon('i-satellite'), el('span', {text: 'Источник: Sentinel-2 L2A' + (r.status === 'ready' ? ` • покрытие пикселями ${pct(r.coverage)}` : '')})));
    meta.append(el('li', {}, icon('i-sprout'), el('span', {text: 'Культура не подтверждена'})));
    left.append(meta);
    const actions = el('div', {class: 'fc-actions'});
    if (r.status === 'ready') {
      const main = el('button', {type: 'button', class: 'btn ' + (primary ? 'btn-primary' : 'btn-outline')}, icon(primary ? 'i-plus' : 'i-pin'), primary ? 'Создать задачу на осмотр' : 'Открыть на карте');
      main.addEventListener('click', () => go('map', {area: r.id}));
      actions.append(main);
    }
    const season = el('button', {type: 'button', class: 'text-button', text: 'Сезон площади'});
    season.addEventListener('click', () => go('season', {area: r.id}));
    actions.append(season);
    left.append(actions);
    card.append(left, thumb(r.id));
    return card;
  }
  function setFilter(f) { S.filter = f; renderToday(); }
  for (const b of document.querySelectorAll('#queue-filter [data-filter]')) b.addEventListener('click', () => setFilter(b.dataset.filter));
  $('queue-sort').addEventListener('change', e => { S.sort = e.target.value; renderToday(); });

  function openTasks() {
    const visited = new Set((S.data.visits || []).map(v => v.payload.task_id));
    return (S.data.tasks || []).slice().reverse().filter(t => !visited.has(t.id));
  }
  function renderTodaySide() {
    const tasks = openTasks();
    $('task-count').textContent = String(tasks.length);
    const list = $('today-tasks');
    if (!tasks.length) list.replaceChildren(el('p', {class: 'task-empty', text: 'Открытых задач нет. Выберите поле в очереди, отметьте место на снимке и задайте вопрос агроному.'}));
    else list.replaceChildren(...tasks.slice(0, 4).map(t => {
      const p = t.payload, b = el('button', {type: 'button', class: 'task-item'},
        el('span', {class: 'initials', text: initials(p.actor), 'aria-hidden': 'true'}),
        el('span', {}, el('strong', {text: 'Площадь ' + p.place.fragment}), el('p', {text: p.objective}), el('small', {text: 'Ответственный: ' + p.actor + (p.planned_date ? ' • ' + day(p.planned_date + 'T12:00:00Z') : '')})));
      b.addEventListener('click', () => { S.visit.task = t.id; go('journal'); });
      return b;
    }));
    const pointer = window.ScoutingDrafts.load(window.ScoutingDrafts.key('desk-task-last', ['pointer']));
    const draft = pointer && window.ScoutingDrafts.load(window.ScoutingDrafts.key('desk-task', [pointer.fid, pointer.placeId]));
    $('resume-draft').hidden = !(draft && draft.objective && draft.objective.trim());
    if (draft) $('resume-draft-note').textContent = 'Задача ' + pointer.fid + ' • ещё не сохранена';
  }
  $('resume-draft').addEventListener('click', e => {
    e.preventDefault();
    const pointer = window.ScoutingDrafts.load(window.ScoutingDrafts.key('desk-task-last', ['pointer']));
    if (!pointer) return;
    S.period = pointer.period; S.pairs[pointer.period] = {before: pointer.before, after: pointer.after};
    S.resumeRelative = pointer.relative; S.fid = pointer.fid; resetPlace(false);
    go('map', {area: pointer.fid});
  });

  // ================= MAP =================
  let lmap = null, shapes = new Map(), overlays = [], placeMarker = null, meMarker = null;
  function initMap() {
    if (lmap) return;
    lmap = L.map('farm-map', {zoomControl: false, minZoom: 10, maxZoom: 18, zoomSnap: .25, attributionControl: true});
    lmap.attributionControl.setPrefix(false);
    lmap.createPane('base'); lmap.getPane('base').style.zIndex = '200';
    overlays = [
      L.imageOverlay('/scouting/assets/wide-basemap.jpg', S.bundle.wide_basemap.bounds, {pane: 'base'}),
      L.imageOverlay('/scouting/assets/basemap.jpg', S.bundle.basemap.bounds, {pane: 'base', attribution: 'Esri, Vantor, Earthstar Geographics · дата мозаики неизвестна'})
    ];
    overlays.forEach(o => o.addTo(lmap));
    L.control.scale({imperial: false, position: 'bottomleft'}).addTo(lmap);
    L.geoJSON(S.bundle.geometry, {
      onEachFeature(feature, layer) {
        const id = feature.properties.id; shapes.set(id, layer);
        layer.bindTooltip(id, {permanent: true, direction: 'center', className: 'field-label', interactive: false});
        layer.on('click', () => { if (S.fid !== id) { S.fid = id; resetPlace(); history.replaceState(null, '', '#map?' + q({area: id})); selectArea(); } });
      }
    }).addTo(lmap);
    lmap.fitBounds(L.geoJSON(S.bundle.geometry).getBounds(), {paddingTopLeft: [40, 80], paddingBottomRight: [40, 120]});
    $('zoom-in').addEventListener('click', () => lmap.zoomIn());
    $('zoom-out').addEventListener('click', () => lmap.zoomOut());
    $('fit-all').addEventListener('click', () => lmap.fitBounds(L.geoJSON(S.bundle.geometry).getBounds(), {paddingTopLeft: [40, 80], paddingBottomRight: [40, 120]}));
    for (const b of document.querySelectorAll('[data-basemap]')) b.addEventListener('click', () => setBasemap(b.dataset.basemap));
    $('locate-me').addEventListener('click', locate);
    if (store.get(KEYS.help) !== 'seen') $('map-help').hidden = false;
    const hide = () => { $('map-help').hidden = true; store.set(KEYS.help, 'seen'); };
    $('map-help-ok').addEventListener('click', hide); $('map-help-close').addEventListener('click', hide);
    new ResizeObserver(() => lmap.invalidateSize({pan: false})).observe($('farm-map'));
  }
  function setBasemap(mode) {
    for (const b of document.querySelectorAll('[data-basemap]')) b.setAttribute('aria-pressed', String(b.dataset.basemap === mode));
    $('farm-map').classList.toggle('scheme', mode === 'scheme');
    for (const o of overlays) mode === 'scheme' ? lmap.removeLayer(o) : o.addTo(lmap);
    paintShapes();
  }
  function paintShapes() {
    if (!lmap) return;
    const ws = currentWs(), scheme = $('farm-map').classList.contains('scheme');
    for (const [id, layer] of shapes) {
      const st = classify(ws?.rows?.find(r => r.id === id)), sel = id === S.fid;
      layer.setStyle({color: sel ? '#FFFFFF' : scheme ? '#FFFFFF' : 'rgba(255,255,255,.9)', weight: sel ? 4 : 1.6, dashArray: sel ? '10 7' : null,
        fillColor: STATUS[st].map, fillOpacity: scheme ? (sel ? .75 : .55) : (sel ? .28 : .16)});
      const t = layer.getTooltip()?.getElement(); if (t) t.classList.toggle('active', sel);
      if (sel) layer.bringToFront();
    }
    const legend = $('map-legend'); legend.replaceChildren(el('strong', {text: 'Цвет обводки:'}));
    for (const k of ORDER) { const sp = el('span', {}); const i = icon(STATUS[k].icon); i.style.color = STATUS[k].map; sp.append(i, STATUS[k].short); legend.append(sp); }
  }
  function locate() {
    if (!navigator.geolocation) return toast('Браузер не даёт определить положение.', {error: true});
    navigator.geolocation.getCurrentPosition(p => {
      const ll = [p.coords.latitude, p.coords.longitude];
      if (meMarker) lmap.removeLayer(meMarker);
      meMarker = L.marker(ll, {icon: L.divIcon({className: '', html: '<div class="me-pin"></div>', iconSize: [18, 18]}), keyboard: false}).addTo(lmap);
      if (L.latLngBounds(S.bundle.basemap.bounds).contains(ll)) lmap.setView(ll, 15);
      else toast('Вы находитесь за пределами карты хозяйства. Положение отмечено точкой.');
    }, () => toast('Положение недоступно: доступ не разрешён или нет сигнала.', {error: true}), {enableHighAccuracy: true, timeout: 10000});
  }
  async function openMap() {
    paintPeriodSwitches();
    initMap();
    requestAnimationFrame(() => lmap.invalidateSize({pan: false}));
    await ensurePeriod(S.period);
    fillPairSelects();
    paintShapes();
    await selectArea();
  }
  function fillPairSelects() {
    const ws = currentWs(); const scenes = ws?.scenes || [];
    const p = S.pairs[S.period];
    for (const [id, side] of [['pair-before', 'before'], ['pair-after', 'after']]) {
      $(id).replaceChildren(...scenes.map(s => el('option', {value: s.id, text: day(s.at), title: `Пригодны ${s.usable_areas} из 27 площадей • обработка ${s.baseline || '—'}`})));
      if (p) $(id).value = p[side];
    }
  }
  $('apply-pair').addEventListener('click', async () => {
    const before = $('pair-before').value, after = $('pair-after').value;
    $('apply-pair').disabled = true;
    try {
      const ws = await loadWorkspace(S.period, {before, after});
      S.pairs[S.period] = {before: ws.pair.before.id, after: ws.pair.after.id};
      resetPlace(); paintShapes(); await selectArea();
      toast(`Общая пара обновлена: ${day(ws.pair.before.at)} → ${day(ws.pair.after.at)}, пригодны ${ws.available_areas}/${ws.total_areas}. Эта же пара используется в очереди «Сегодня».`);
    } catch (e) { fillPairSelects(); toast(e.message, {error: true}); } finally { $('apply-pair').disabled = false; }
  });
  for (const b of document.querySelectorAll('[data-metric]')) b.addEventListener('click', () => {
    S.metric = b.dataset.metric;
    for (const x of document.querySelectorAll('[data-metric]')) x.setAttribute('aria-pressed', String(x === b));
    renderImages(); renderLegend(); renderPlaceBox();
  });
  function renderLegend() {
    $('index-legend').replaceChildren(...RAMPS[S.metric].map(([c, t]) => { const i = el('i'); i.style.background = c; return el('li', {}, i, t); }), el('li', {}, el('i', {class: 'hatch'}), 'Нет данных (облака, тени)'));
  }
  function resetPlace(clearResume = true) {
    S.place = null; S.placeSource = null; S.relative = null; S.placeConfirmed = false; S.placeComparison = null;
    if (clearResume) S.resumeRelative = null;
    ++runs.place;
    if (placeMarker && lmap) { lmap.removeLayer(placeMarker); placeMarker = null; }
  }
  async function selectArea() {
    paintShapes();
    const fid = S.fid, run = ++runs.area;
    if (shapes.get(fid) && lmap) lmap.fitBounds(shapes.get(fid).getBounds(), {paddingTopLeft: [60, 120], paddingBottomRight: [60, 160], maxZoom: 15});
    $('map-area-code').textContent = fid;
    const row = currentWs()?.rows?.find(r => r.id === fid), st = classify(row);
    $('map-area-status').replaceWith(Object.assign(badge(st), {id: 'map-area-status'}));
    $('map-area-summary').textContent = row?.status === 'ready' ? `ΔNDVI ${signed(row.ndvi.base)} • ΔNDMI ${signed(row.ndmi.base)} • ${robustText(row)}` : '';
    for (const img of [$('img-before'), $('img-after'), $('swipe-before'), $('swipe-after')]) img.dataset.loading = '';
    let detail;
    try { detail = await loadArea(fid, S.period); } catch (e) { if (run === runs.area) toast(e.message, {error: true}); return; }
    if (run !== runs.area) return;
    S.detail = detail;
    if (!S.place && detail?.pair) {
      if (S.resumeRelative) {
        const rel = S.resumeRelative; S.resumeRelative = null;
        await pickRelative(rel);
      } else { S.place = detail.default_location; S.placeComparison = detail.default_place_comparison; S.placeSource = 'reference'; }
    }
    renderImages(); renderLegend(); renderPlaceBox(); restoreTaskDraft(); taskReady();
  }
  function mapUrl(side) {
    const p = S.detail.pair;
    return '/api/scouting/map?' + q({fid: S.detail.fragment, period: S.detail.period, before: p.before.id, after: p.after.id, key: S.metric, side});
  }
  function renderImages() {
    const d = S.detail, ok = !!d?.pair;
    $('compare-missing').hidden = ok;
    $('compare-images').hidden = !ok || S.swipe; $('swipe').hidden = !ok || !S.swipe;
    $('pair-coverage').textContent = ok ? pct(d.pair.coverage) + ` (${d.pair.paired_cells} ячеек по 20 м)` : 'нет пригодной пары';
    if (!ok) { $('compare-missing').replaceChildren(icon('i-nodata'), el('span', {text: (d?.unavailable_reason || 'Нет пригодной пары снимков') + '. Другие даты не подставляются — выберите другую пару или площадь.'})); return; }
    const label = S.metric === 'ndvi' ? 'NDVI' : 'NDMI';
    const set = (img, side) => {
      const url = mapUrl(side);
      if (img.getAttribute('src') !== url) { img.dataset.loading = ''; img.src = url; } else delete img.dataset.loading;
      img.alt = `${label} площади ${d.fragment}, снимок ${day(d.pair[side].at)}. Нажмите внутри обводки, чтобы выбрать место`;
    };
    set($('img-before'), 'before'); set($('img-after'), 'after'); set($('swipe-before'), 'before'); set($('swipe-after'), 'after');
    $('cap-before').textContent = day(d.pair.before.at); $('cap-after').textContent = day(d.pair.after.at); $('swipe-tag-before').textContent = 'Было ' + day(d.pair.before.at); $('swipe-tag-after').textContent = 'Стало ' + day(d.pair.after.at);
    placeMarks(); swipePaint();
  }
  for (const img of [$('img-before'), $('img-after'), $('swipe-before'), $('swipe-after')]) {
    img.addEventListener('load', () => { delete img.dataset.loading; placeMarks(); swipePaint(); });
    img.addEventListener('error', () => { delete img.dataset.loading; toast('Снимок не загрузился. Данные не подменены.', {error: true}); });
    img.addEventListener('click', e => {
      const r = img.getBoundingClientRect();
      if (!r.width || !r.height) return;
      const rel = [Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (e.clientY - r.top) / r.height))];
      pickRelative(rel);
    });
  }
  async function pickRelative(rel) {
    const d = S.detail; if (!d?.pair) return;
    const run = ++runs.place, fid = d.fragment, pair = d.pair;
    $('task-place').textContent = 'Проверяем место…'; $('task-place').classList.remove('ready'); taskReady(true);
    try {
      const res = await api('/api/scouting/location?' + q({fid, period: d.period, before: pair.before.id, after: pair.after.id, relative: JSON.stringify(rel.map(v => Number(v.toFixed(5))))}));
      if (run !== runs.place || S.detail !== d) return;
      saveTaskDraft();
      S.place = res.location; S.placeComparison = res.comparison; S.placeSource = 'click'; S.relative = rel.map(v => Number(v.toFixed(5))); S.placeConfirmed = true;
      renderPlaceBox(); placeMarks(); restoreTaskDraft();
    } catch (e) { if (run === runs.place) { toast(e.message, {error: true}); renderPlaceBox(); } }
    taskReady();
  }
  function cellRect() {
    const d = S.detail, m = /^R\d{2}-(\d+)-(\d+)$/.exec(S.place?.id || '');
    if (!d?.pair || !m) return null;
    const c = d.pair.crop, cx = Number(m[1]) * 60, cy = Number(m[2]) * 60, W = c.width * c.cell_m, H = c.height * c.cell_m;
    return {x: (cx - c.west) / W, y: (c.north - (cy + 60)) / H, w: 60 / W, h: 60 / H};
  }
  function placeMarks() {
    const rect = cellRect();
    const pairs = [[$('img-before'), document.querySelector('[data-side="before"] .window-mark')], [$('img-after'), document.querySelector('[data-side="after"] .window-mark')], [$('swipe-after'), document.querySelector('#swipe-box .window-mark')]];
    for (const [img, mark] of pairs) {
      if (!rect || !img.naturalWidth || !img.offsetWidth) { mark.hidden = true; continue; }
      mark.hidden = false;
      mark.style.left = (img.offsetLeft + rect.x * img.offsetWidth) + 'px';
      mark.style.top = (img.offsetTop + rect.y * img.offsetHeight) + 'px';
      mark.style.width = Math.max(6, rect.w * img.offsetWidth) + 'px';
      mark.style.height = Math.max(6, rect.h * img.offsetHeight) + 'px';
      mark.title = 'Окно 60 × 60 м';
    }
    if (lmap && S.place) {
      const ll = [S.place.latitude, S.place.longitude];
      const html = '<div class="place-pin"><span>Окно 60 × 60 м</span><i></i></div>';
      if (placeMarker) placeMarker.setLatLng(ll); else placeMarker = L.marker(ll, {icon: L.divIcon({className: '', html, iconSize: [120, 56], iconAnchor: [60, 50]}), keyboard: false, interactive: false}).addTo(lmap);
    }
  }
  new ResizeObserver(() => placeMarks()).observe($('compare-images'));
  $('toggle-swipe').addEventListener('click', () => { S.swipe = !S.swipe; $('toggle-swipe').setAttribute('aria-pressed', String(S.swipe)); $('swipe-toggle-back')?.remove(); renderImages(); if (S.swipe) addSwipeBack(); });
  function addSwipeBack() {
    const b = el('button', {type: 'button', class: 'text-button', id: 'swipe-toggle-back', text: 'Показать рядом'});
    b.addEventListener('click', () => { S.swipe = false; $('toggle-swipe').setAttribute('aria-pressed', 'false'); b.remove(); renderImages(); });
    $('swipe').append(b);
  }
  $('swipe-range').addEventListener('input', swipePaint);
  function swipePaint() {
    const v = Number($('swipe-range').value), img = $('swipe-after');
    img.style.clipPath = `inset(0 0 0 ${v}%)`;
    $('swipe-line').style.left = (img.offsetLeft + img.offsetWidth * v / 100 - 1) + 'px';
    $('swipe-range').setAttribute('aria-valuetext', `Слева ${S.detail?.pair ? day(S.detail.pair.before.at) : ''}, справа ${S.detail?.pair ? day(S.detail.pair.after.at) : ''}`);
    placeMarks();
  }
  function renderPlaceBox() {
    const box = $('place-box'); box.replaceChildren();
    const chip = $('task-place');
    if (!S.detail?.pair || !S.place) { chip.textContent = 'Место не выбрано'; chip.classList.remove('ready'); return; }
    const c = S.placeComparison;
    box.append(el('strong', {text: S.placeSource === 'click' ? 'Выбранное место • окно 60 м' : 'Опорная точка площади • окно 60 м'}));
    box.append(el('span', {text: S.place.id}));
    if (c && c.paired_cells >= 5 && c.coverage >= .8) box.append(el('span', {text: `ΔNDVI ${signed(c.ndvi)} • ΔNDMI ${signed(c.ndmi)} • ${c.paired_cells}/${c.total_cells} ячеек`}));
    else box.append(el('span', {class: 'muted', text: `Окно не покрыто пригодными пикселями (${c?.paired_cells ?? 0}/${c?.total_cells ?? 0}). Изменение места неизвестно.`}));
    if (!S.placeConfirmed) {
      const b = el('button', {type: 'button', class: 'btn btn-secondary', text: 'Использовать эту точку'});
      b.addEventListener('click', () => { S.placeConfirmed = true; renderPlaceBox(); taskReady(); });
      box.append(b, el('small', {class: 'muted', text: 'Или нажмите на снимок внутри обводки.'}));
    }
    chip.textContent = S.placeConfirmed ? `Место подтверждено: ${S.place.id} • опора окна, не GPS` : 'Подтвердите точку или выберите место на снимке';
    chip.classList.toggle('ready', S.placeConfirmed);
  }

  // task form
  function taskDraftKey() { return S.place ? window.ScoutingDrafts.key('desk-task', [S.detail.fragment, S.place.id]) : ''; }
  function saveTaskDraft() {
    const key = taskDraftKey(); if (!key || !S.placeConfirmed) return;
    const value = {objective: $('task-objective').value, actor: $('task-actor').value, date: $('task-date').value, request: S.taskRequest};
    if (!value.objective.trim()) { window.ScoutingDrafts.remove(key); return; }
    window.ScoutingDrafts.save(key, value);
    const p = S.detail.pair;
    window.ScoutingDrafts.save(window.ScoutingDrafts.key('desk-task-last', ['pointer']), {fid: S.detail.fragment, placeId: S.place.id, period: S.detail.period, before: p.before.id, after: p.after.id, relative: S.placeSource === 'click' ? S.relative : null});
  }
  function restoreTaskDraft() {
    const key = taskDraftKey(); if (!key) return;
    const d = window.ScoutingDrafts.load(key);
    if (d && typeof d.objective === 'string') {
      $('task-objective').value = d.objective.slice(0, 2000); $('task-actor').value = String(d.actor || defaultActor()).slice(0, 120); $('task-date').value = /^\d{4}-\d{2}-\d{2}$/.test(d.date) ? d.date : '';
      if (/^[a-f0-9]{32}$/.test(d.request)) S.taskRequest = d.request;
      $('task-status').textContent = 'Черновик восстановлен. Задача ещё не создана.';
    }
  }
  function taskReady(pending = false) {
    const ok = !!S.detail?.pair && S.placeConfirmed && !pending && !S.taskBusy && $('task-objective').value.trim() && $('task-actor').value.trim();
    $('save-task').disabled = !ok;
  }
  for (const id of ['task-objective', 'task-actor', 'task-date']) $(id).addEventListener('input', () => { saveTaskDraft(); taskReady(); if ($('task-objective').value.trim()) $('task-status').textContent = 'Черновик в этой вкладке. Задача ещё не создана.'; });
  $('task-form').addEventListener('submit', async e => {
    e.preventDefault();
    if ($('save-task').disabled || S.taskBusy) return;
    const d = S.detail, p = d.pair;
    const body = {request_id: S.taskRequest, fragment: d.fragment, period: d.period, before: p.before.id, after: p.after.id, version: p.version,
      relative: S.placeSource === 'click' ? S.relative : null, actor: $('task-actor').value.trim(), planned_date: $('task-date').value || '', objective: $('task-objective').value.trim(), metric: S.metric};
    S.taskBusy = true; taskReady(); $('task-status').classList.remove('error'); $('task-status').textContent = 'Сохраняем задачу и её основание…';
    try {
      const saved = await api('/api/scouting/tasks', body);
      window.ScoutingDrafts.remove(taskDraftKey());
      S.taskRequest = uid(); $('task-objective').value = ''; $('task-date').value = '';
      await refreshState();
      $('task-status').textContent = `Задача сохранена (${saved.payload.place.id}). Это вопрос для осмотра, не посещение.`;
      toast('Задача на осмотр сохранена.', {action: 'Добавить в выезд', onAction: () => { addToTrip(saved.id); go('trip'); }});
    } catch (err) { $('task-status').classList.add('error'); $('task-status').textContent = err.message; }
    finally { S.taskBusy = false; taskReady(); }
  });

  // ================= SEASON =================
  async function renderSeason() {
    paintPeriodSwitches();
    if (!$('season-area').options.length) {
      $('season-area').replaceChildren(...Object.keys(S.bundle.features).sort().map(id => el('option', {value: id, text: 'Площадь ' + id})));
      $('season-area').addEventListener('change', e => { S.seasonFid = e.target.value; S.seasonScene = null; history.replaceState(null, '', '#season?' + q({area: S.seasonFid})); renderSeason(); });
    }
    $('season-area').value = S.seasonFid;
    const run = ++runs.season;
    $('season-chart').replaceChildren(el('p', {class: 'muted', text: 'Строим ряд площади…'}));
    const ws = await ensurePeriod(S.period);
    const detail = ws?.pair ? await loadArea(S.seasonFid, S.period) : null;
    if (run !== runs.season) return;
    S.seasonDetail = detail;
    renderSeasonChart(ws, detail); renderSeasonThumbs(detail); renderSceneTable(detail); renderSeasonFacts(ws, detail); seasonReady();
  }
  for (const b of document.querySelectorAll('[data-season-metric]')) b.addEventListener('click', () => {
    S.seasonMetric = b.dataset.seasonMetric;
    for (const x of document.querySelectorAll('[data-season-metric]')) x.setAttribute('aria-pressed', String(x === b));
    renderSeasonChart(currentWs(), S.seasonDetail); renderSeasonThumbs(S.seasonDetail);
  });
  function renderSeasonChart(ws, detail) {
    const box = $('season-chart'); box.replaceChildren();
    const key = S.seasonMetric, label = key === 'ndvi' ? 'Индекс зелёной массы (NDVI)' : 'Индекс влажности покрова (NDMI)';
    const visits = (S.data.visits || []).filter(v => v.payload.place.fragment === S.seasonFid);
    const legend = $('season-legend'); legend.replaceChildren();
    const li = (node, text) => legend.append(el('li', {}, node, text));
    const dot = el('i'); dot.style.background = 'var(--green)'; li(dot, label + ', медиана площади');
    li(el('i', {class: 'hatch'}), 'Облачный пропуск');
    const inPeriod = visits.filter(v => { const t = new Date(v.payload.observed_at_utc).getTime(), pr = S.data.periods.find(p => p.id === S.period); return pr && t >= new Date(pr.start).getTime() && t <= new Date(pr.end).getTime(); }).length;
    li(el('i', {class: 'bar'}), !visits.length ? 'Осмотр (записей пока нет)' : inPeriod === visits.length ? 'Осмотр' : `Осмотр (${visits.length - inPeriod} вне этого периода — в журнале)`);
    if (!detail) { box.append(el('p', {class: 'nodata-panel', text: 'Нет общей пары для этого периода.'})); return; }
    const period = S.data.periods.find(p => p.id === S.period);
    const rows = detail.dates.slice().sort((a, b) => new Date(a.at) - new Date(b.at));
    const vals = rows.filter(r => r.usable && isNum(r[key])).map(r => r[key]);
    if (!vals.length) { box.append(el('p', {class: 'nodata-panel', text: 'В этом периоде нет пригодных снимков площади.'})); return; }
    const W = Math.max(640, box.clientWidth || 900), H = 260, m = {l: 54, r: 16, t: 14, b: 42};
    const t0 = new Date(rows[0].at).getTime() - 2 * 864e5, t1 = new Date(rows[rows.length - 1].at).getTime() + 2 * 864e5;
    let lo = Math.min(...vals), hi = Math.max(...vals); const padv = Math.max(.05, (hi - lo) * .15); lo = Math.floor((lo - padv) * 10) / 10; hi = Math.ceil((hi + padv) * 10) / 10;
    const x = t => m.l + (t - t0) / (t1 - t0) * (W - m.l - m.r), y = v => m.t + (hi - v) / (hi - lo) * (H - m.t - m.b);
    const s = svgEl('svg', {viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': `${label} площади ${S.seasonFid}, ${PERIOD_LABEL[S.period]}. Таблица значений ниже в разделе «Все снимки периода».`});
    s.style.height = H + 'px';
    const defs = svgEl('defs', {}, s), pat = svgEl('pattern', {id: 'hatch', width: 5, height: 5, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)'}, defs);
    svgEl('rect', {width: 5, height: 5, fill: '#EEF0EE'}, pat); svgEl('line', {x1: 0, y1: 0, x2: 0, y2: 5, stroke: '#9AA39E', 'stroke-width': 2}, pat);
    const p = S.pairs[S.period];
    const pb = rows.find(r => r.id === p?.before), pa = rows.find(r => r.id === p?.after);
    if (pb && pa) {
      svgEl('rect', {class: 'pair-mark', x: x(new Date(pb.at)), y: m.t, width: Math.max(2, x(new Date(pa.at)) - x(new Date(pb.at))), height: H - m.t - m.b}, s);
    }
    const grid = svgEl('g', {class: 'grid'}, s), axis = svgEl('g', {class: 'axis'}, s);
    const step = (hi - lo) > .8 ? .2 : .1;
    for (let v = lo; v <= hi + 1e-9; v += step) { svgEl('line', {x1: m.l, x2: W - m.r, y1: y(v), y2: y(v)}, grid); svgEl('text', {x: m.l - 8, y: y(v) + 4, 'text-anchor': 'end'}, axis).textContent = num(v, 1); }
    const ticks = 8;
    for (let i = 0; i <= ticks; i++) { const t = t0 + (t1 - t0) * i / ticks; svgEl('text', {x: x(t), y: H - 16, 'text-anchor': 'middle'}, axis).textContent = dayShort(t); }
    svgEl('text', {x: m.l, y: H - 2}, axis).textContent = period ? PERIOD_LABEL[S.period] : '';
    // processing-baseline changes are processing events, not crop events
    let prev = null, baselineChanged = false;
    for (const r of rows) {
      if (prev && r.baseline && prev.baseline && r.baseline !== prev.baseline) {
        const xx = (x(new Date(prev.at)) + x(new Date(r.at))) / 2;
        svgEl('line', {class: 'baseline-change', x1: xx, x2: xx, y1: m.t, y2: H - m.b}, s);
        svgEl('text', {x: xx + 4, y: m.t + 10, class: 'axis'}, axis).textContent = `версия обработки ${prev.baseline} → ${r.baseline}`;
        baselineChanged = true;
      }
      prev = r;
    }
    for (const v of visits) {
      const t = new Date(v.payload.observed_at_utc).getTime(); if (t < t0 || t > t1) continue;
      const l = svgEl('line', {class: 'visit', x1: x(t), x2: x(t), y1: m.t, y2: H - m.b}, s);
      svgEl('title', {}, l).textContent = 'Осмотр ' + day(v.payload.observed_at_utc) + ' • ' + OUTCOME[v.payload.outcome].label;
    }
    // line segments break at every unusable scene: no interpolation across gaps
    let seg = [];
    const flush = () => { if (seg.length > 1) svgEl('path', {class: 'series', d: seg.map((pt, i) => (i ? 'L' : 'M') + pt[0].toFixed(1) + ' ' + pt[1].toFixed(1)).join(' ')}, s); seg = []; };
    for (const r of rows) { if (r.usable && isNum(r[key])) seg.push([x(new Date(r.at)), y(r[key])]); else flush(); }
    flush();
    const points = [];
    for (const r of rows) {
      const cx = x(new Date(r.at));
      if (r.usable && isNum(r[key])) { const c = svgEl('circle', {class: 'pt', cx, cy: y(r[key]), r: r.id === S.seasonScene ? 7 : 4.5}, s); points.push({r, cx, cy: y(r[key]), c}); }
      else { const g = svgEl('circle', {class: 'gap', cx, cy: H - m.b - 7, r: 6}, s); points.push({r, cx, cy: H - m.b - 7, gap: true}); svgEl('title', {}, g).textContent = day(r.at) + ' — нет пригодных данных'; }
    }
    if (pb && pa) { const sw = el('i'); sw.style.background = 'var(--green-soft)'; sw.style.borderRadius = '3px'; sw.style.border = '1px solid var(--green-line)'; li(sw, `Пара сравнения ${dayShort(pb.at)} → ${dayShort(pa.at)}`); }
    if (baselineChanged) li(el('i', {class: 'vline'}), 'Смена версии обработки (не событие на поле)');
    const cross = svgEl('line', {class: 'cross', y1: m.t, y2: H - m.b, x1: -10, x2: -10}, s);
    box.append(s);
    const tip = el('div', {class: 'chart-tip', hidden: true}); box.append(tip);
    s.addEventListener('pointermove', e => {
      const r = s.getBoundingClientRect(), px = (e.clientX - r.left) * W / r.width;
      let best = null; for (const pt of points) if (!best || Math.abs(pt.cx - px) < Math.abs(best.cx - px)) best = pt;
      if (!best) return;
      cross.setAttribute('x1', best.cx); cross.setAttribute('x2', best.cx);
      tip.hidden = false; tip.style.left = (best.cx * r.width / W) + 'px'; tip.style.top = (best.cy * r.height / H) + 'px';
      tip.textContent = best.gap ? `${day(best.r.at)} • облачный пропуск, покрытие ${pct(best.r.coverage)}` : `${day(best.r.at)} • ${key.toUpperCase()} ${num(best.r[key])} • покрытие ${pct(best.r.coverage)}`;
    });
    s.addEventListener('pointerleave', () => { tip.hidden = true; cross.setAttribute('x1', -10); cross.setAttribute('x2', -10); });
  }
  function renderSeasonThumbs(detail) {
    const box = $('season-thumbs'); box.replaceChildren();
    const usable = (detail?.dates || []).filter(r => r.usable).sort((a, b) => new Date(a.at) - new Date(b.at));
    if (usable.length < 2) { box.append(el('p', {class: 'muted', text: 'Недостаточно пригодных снимков для миниатюр.'})); return; }
    const n = Math.min(6, usable.length), picks = [...new Set(Array.from({length: n}, (_, i) => Math.round(i * (usable.length - 1) / (n - 1))))];
    for (const i of picks) {
      const r = usable[i], last = i === usable.length - 1;
      const before = last ? usable[i - 1] : r, after = last ? r : usable[i + 1];
      const url = '/api/scouting/map?' + q({fid: S.seasonFid, period: S.period, before: before.id, after: after.id, key: S.seasonMetric, side: last ? 'after' : 'before'});
      const b = el('button', {type: 'button', class: 'scene-thumb', 'aria-pressed': String(S.seasonScene === r.id), 'aria-label': `Снимок ${day(r.at)}, ${S.seasonMetric.toUpperCase()}; выделить на графике`},
        el('img', {src: url, alt: '', loading: 'lazy'}), el('span', {text: dayShort(r.at)}));
      b.addEventListener('click', () => { S.seasonScene = S.seasonScene === r.id ? null : r.id; renderSeasonChart(currentWs(), S.seasonDetail); renderSeasonThumbs(S.seasonDetail); });
      box.append(b);
    }
  }
  function renderSceneTable(detail) {
    const rows = (detail?.dates || []).slice().sort((a, b) => new Date(a.at) - new Date(b.at));
    $('scene-rows').replaceChildren(...rows.map(r => el('tr', {}, el('td', {text: day(r.at)}), el('td', {text: r.usable ? 'да' : 'нет'}), el('td', {text: pct(r.coverage)}), el('td', {text: num(r.ndvi)}), el('td', {text: num(r.ndmi)}), el('td', {text: r.baseline || '—'}))));
    $('all-scenes').querySelector('summary').textContent = `Все снимки периода (${rows.length}, пригодны ${rows.filter(r => r.usable).length})`;
  }
  function renderSeasonFacts(ws, detail) {
    const f = $('season-facts'); f.replaceChildren();
    const row = ws?.rows?.find(r => r.id === S.seasonFid);
    if (!ws?.pair) { f.append(el('li', {text: 'Нет общей пары дат для периода.'})); return; }
    const span = `${day(ws.pair.before.at)} → ${day(ws.pair.after.at)}`;
    if (!row || row.status !== 'ready') { f.append(el('li', {text: `${span}: ${row?.reason || 'нет пригодной пары'}. Изменение неизвестно.`})); }
    else {
      f.append(el('li', {text: `Зелёная масса (NDVI) площади: ${signed(row.ndvi.base)} за ${days(ws.pair.days)} (${span}).`}));
      f.append(el('li', {text: `Влажность покрова (NDMI): ${signed(row.ndmi.base)}. Это спутниковый сигнал, не датчик влажности почвы.`}));
      f.append(el('li', {text: row.ndvi.robust && row.ndmi.robust ? 'Знак и величина устойчивы к смещению обводки на 50–100 м.' : 'Оценка чувствительна к положению приблизительных границ.'}));
      f.append(el('li', {text: `Покрытие общей пары: ${pct(row.coverage)}. Это полнота данных, не точность модели.`}));
    }
    f.append(el('li', {text: 'Контур поля приблизительный; культура и причина изменения не установлены.'}));
    $('season-place').textContent = detail?.default_location ? detail.default_location.id : '—';
  }
  function seasonReady() {
    const ok = !!S.seasonDetail?.pair && $('season-confirm').checked && $('season-note').value.trim() && $('season-actor').value.trim() && !S.seasonBusy;
    $('season-save').disabled = !ok;
    if (!S.seasonDetail?.pair && S.view === 'season') $('season-status').textContent = 'Для этой площади нет пригодной пары — задачу привязать не к чему.';
  }
  for (const id of ['season-note', 'season-actor', 'season-date', 'season-confirm']) $(id).addEventListener('input', seasonReady);
  $('season-form').addEventListener('submit', async e => {
    e.preventDefault(); if ($('season-save').disabled) return;
    const d = S.seasonDetail, p = d.pair;
    S.seasonBusy = true; seasonReady(); $('season-status').classList.remove('error'); $('season-status').textContent = 'Сохраняем…';
    try {
      await api('/api/scouting/tasks', {request_id: S.seasonRequest, fragment: d.fragment, period: d.period, before: p.before.id, after: p.after.id, version: p.version, relative: null,
        actor: $('season-actor').value.trim(), planned_date: $('season-date').value || '', objective: $('season-note').value.trim(), metric: S.seasonMetric});
      S.seasonRequest = uid(); $('season-note').value = ''; $('season-date').value = ''; $('season-confirm').checked = false;
      await refreshState();
      $('season-status').textContent = 'Задача сохранена: опорная точка площади ' + d.fragment + '. Это план проверки, не посещение.';
      toast('Проверка запланирована.', {action: 'Открыть выезд', onAction: () => go('trip')});
    } catch (err) { $('season-status').classList.add('error'); $('season-status').textContent = err.message; }
    finally { S.seasonBusy = false; seasonReady(); }
  });

  // ================= TRIP =================
  const planDraftKey = window.ScoutingDrafts.key('desk-plan', ['builder']);
  (() => {
    const d = window.ScoutingDrafts.load(planDraftKey);
    if (!d) return;
    if (typeof d.title === 'string') $('plan-title').value = d.title.slice(0, 160);
    if (['inspection', 'sensor_survey'].includes(d.purpose)) $('plan-purpose').value = d.purpose;
    if (Array.isArray(d.order)) S.trip.order = d.order.filter(x => typeof x === 'string').slice(0, 3);
    if (typeof d.request === 'string' && /^[a-f0-9]{32}$/.test(d.request)) S.trip.request = d.request;
  })();
  function savePlanDraft() {
    const v = {title: $('plan-title').value, purpose: $('plan-purpose').value, order: S.trip.order, request: S.trip.request};
    if (!v.title.trim() && !v.order.length && v.purpose === 'inspection') window.ScoutingDrafts.remove(planDraftKey); else window.ScoutingDrafts.save(planDraftKey, v);
  }
  function taskById(id) { return (S.data.tasks || []).find(t => t.id === id); }
  function addToTrip(id) {
    const t = taskById(id); if (!t || S.trip.order.includes(id)) return true;
    if (S.trip.order.length >= 3) { toast('В один план входит до трёх мест.', {error: true}); return false; }
    if (S.trip.order.some(x => taskById(x)?.payload.place.id === t.payload.place.id)) { toast('Это место уже есть в плане через другую задачу.', {error: true}); return false; }
    S.trip.order.push(id); if (!$('plan-title').value.trim()) $('plan-title').value = 'Осмотр ' + t.payload.place.fragment;
    S.trip.report = null; savePlanDraft(); return true;
  }
  function renderTrip() {
    const tasks = (S.data.tasks || []).slice().reverse();
    S.trip.order = S.trip.order.filter(id => taskById(id));
    $('trip-empty').hidden = tasks.length > 0;
    const viewing = !!S.trip.report && !S.trip.order.length;
    $('plan-form').hidden = !tasks.length || viewing;
    if (viewing) {
      const r = S.trip.report, again = el('button', {type: 'button', class: 'btn btn-outline'}, icon('i-plus'), 'Собрать новый план');
      again.addEventListener('click', () => { S.trip.report = null; renderTrip(); });
      const head = el('li', {class: 'card plan-banner'}, el('div', {}, el('h2', {text: 'Сохранённый план: ' + r.plan.payload.title}), el('p', {class: 'muted small', text: `${r.plan.payload.purpose_label} • сохранён ${dateTime(r.plan.recorded_at_utc)} • статус: запланирован, не посещён`})), again);
      $('trip-list').replaceChildren(head, ...r.tasks.map((t, i) => tripItem(t, null, i)));
    } else {
      const ordered = [...S.trip.order.map(taskById), ...tasks.filter(t => !S.trip.order.includes(t.id))];
      $('trip-list').replaceChildren(...ordered.map(t => tripItem(t, null)));
    }
    planReady(); renderSavedPlans(); renderTripMap(); renderChecklist();
  }
  function tripItem(t, ws, fixed) {
    const p = t.payload, i = fixed ?? S.trip.order.indexOf(t.id), on = i >= 0, locked = fixed !== undefined;
    const row = {status: 'ready', ndvi: p.evidence.metrics.ndvi, ndmi: p.evidence.metrics.ndmi}; // status of the task's own archive pair
    const visits = (S.data.visits || []).filter(v => v.payload.place.id === p.place.id);
    const li = el('li', {class: 'trip-item' + (on ? ' chosen' : ''), draggable: on && !locked ? 'true' : 'false', 'data-id': t.id});
    li.append(el('span', {class: 'grip', 'aria-hidden': 'true'}, on && !locked ? icon('i-grip') : ''));
    li.append(el('span', {class: 'order' + (on ? '' : ' off'), text: on ? String(i + 1) : '–', 'aria-label': on ? 'Место ' + (i + 1) + ' в плане' : 'Не в плане'}));
    li.append(thumb(p.place.fragment, false));
    const body = el('div', {});
    body.append(el('h3', {text: 'Площадь ' + p.place.fragment}));
    const st = row ? classify(row) : null;
    if (st) body.append(badge(st));
    body.append(el('p', {class: 'q', text: 'Вопрос агроному: ' + p.objective}));
    body.append(el('ul', {class: 'meta'}, el('li', {}, icon('i-cal'), el('span', {text: `Снимки: ${day(p.evidence.before.at)} → ${day(p.evidence.after.at)} • ${p.metric.toUpperCase()} места ${signed(p.place_evidence?.[p.metric])}`})),
      el('li', {}, icon('i-user'), el('span', {text: p.actor + (p.planned_date ? ' • план ' + day(p.planned_date + 'T12:00:00Z') : '') + ' • ' + (visits.length ? 'осмотров места: ' + visits.length : 'осмотров ещё не было')}))));
    li.append(body);
    const acts = el('div', {class: 'trip-actions'});
    const inc = el('label', {class: 'include'}, el('input', {type: 'checkbox', checked: on}), 'В плане');
    inc.querySelector('input').addEventListener('change', e => {
      if (e.target.checked) { if (!addToTrip(t.id)) e.target.checked = false; } else { S.trip.order = S.trip.order.filter(x => x !== t.id); savePlanDraft(); }
      renderTrip();
    });
    const open = el('button', {type: 'button', class: 'btn btn-outline'}, icon('i-pin'), 'Открыть на карте');
    open.addEventListener('click', () => openTaskOnMap(t));
    if (!locked) acts.append(inc);
    acts.append(open);
    if (on && !locked) {
      const row2 = el('div', {class: 'row'});
      const up = el('button', {type: 'button', class: 'icon-button', 'aria-label': 'Выше в порядке', disabled: i === 0}, icon('i-up'));
      const down = el('button', {type: 'button', class: 'icon-button', 'aria-label': 'Ниже в порядке', disabled: i === S.trip.order.length - 1}, icon('i-down'));
      up.addEventListener('click', () => move(t.id, -1)); down.addEventListener('click', () => move(t.id, 1));
      row2.append(up, down); acts.append(row2);
    }
    body.append(acts);
    li.addEventListener('click', e => { if (e.target.closest('button,input,label')) return; S.trip.focus = t.id; renderChecklist(); });
    li.addEventListener('dragstart', e => { e.dataTransfer.setData('text/plain', t.id); li.classList.add('dragging'); });
    li.addEventListener('dragend', () => li.classList.remove('dragging'));
    li.addEventListener('dragover', e => { if (on) e.preventDefault(); });
    li.addEventListener('drop', e => { e.preventDefault(); const from = e.dataTransfer.getData('text/plain'); const a = S.trip.order.indexOf(from), b = S.trip.order.indexOf(t.id); if (a < 0 || b < 0 || a === b) return; S.trip.order.splice(a, 1); S.trip.order.splice(b, 0, from); S.trip.report = null; savePlanDraft(); renderTrip(); });
    return li;
  }
  function move(id, dir) { const a = S.trip.order.indexOf(id), b = a + dir; if (b < 0 || b >= S.trip.order.length) return; [S.trip.order[a], S.trip.order[b]] = [S.trip.order[b], S.trip.order[a]]; S.trip.report = null; savePlanDraft(); renderTrip(); }
  function openTaskOnMap(t) {
    const p = t.payload; S.period = p.period; S.pairs[p.period] = {before: p.evidence.before.id, after: p.evidence.after.id}; S.metric = p.metric;
    for (const x of document.querySelectorAll('[data-metric]')) x.setAttribute('aria-pressed', String(x.dataset.metric === S.metric));
    S.fid = p.place.fragment; resetPlace();
    S.pendingTaskPlace = p.place;
    go('map', {area: p.place.fragment});
    loadWorkspace(p.period, S.pairs[p.period]).then(() => { if (S.pendingTaskPlace && S.view === 'map') { S.place = S.pendingTaskPlace; S.placeComparison = p.place_evidence; S.placeSource = 'task'; S.placeConfirmed = false; S.pendingTaskPlace = null; renderPlaceBox(); placeMarks(); } }).catch(() => {});
  }
  function planReady() {
    const n = S.trip.order.length;
    $('plan-hint').textContent = `Выбрано ${n} / 3. Дорожный маршрут не оптимизируется: порядок задаёте вы.`;
    $('save-plan').disabled = S.trip.busy || n < 1 || n > 3 || !$('plan-title').value.trim();
  }
  $('plan-title').addEventListener('input', () => { savePlanDraft(); planReady(); });
  $('plan-purpose').addEventListener('change', () => { savePlanDraft(); planReady(); });
  $('plan-form').addEventListener('submit', async e => {
    e.preventDefault(); if ($('save-plan').disabled) return;
    S.trip.busy = true; planReady(); $('plan-status').classList.remove('error'); $('plan-status').textContent = 'Сохраняем план и основание задач…';
    try {
      const plan = await api('/api/scouting/plans', {request_id: S.trip.request, title: $('plan-title').value.trim(), task_ids: S.trip.order.slice(), purpose: $('plan-purpose').value});
      S.trip.request = uid(); S.trip.order = []; $('plan-title').value = ''; $('plan-purpose').value = 'inspection'; window.ScoutingDrafts.remove(planDraftKey);
      await refreshState();
      $('plan-status').textContent = 'План сохранён. Он не является записью посещения.';
      await openReport(plan.id); renderTrip();
      toast('План выезда сохранён. Лист готов к скачиванию.', {action: 'Скачать лист', onAction: downloadSheet});
    } catch (err) { $('plan-status').classList.add('error'); $('plan-status').textContent = err.message; }
    finally { S.trip.busy = false; planReady(); }
  });
  function renderSavedPlans() {
    const plans = (S.data.plans || []).slice().reverse(), sel = $('saved-plans');
    sel.replaceChildren(...(plans.length ? [el('option', {value: '', text: 'Выберите сохранённый план'}), ...plans.map(p => el('option', {value: p.id, text: `${p.payload.title} • ${p.payload.task_ids.length} ${plural(p.payload.task_ids.length, 'место', 'места', 'мест')} • ${day(p.recorded_at_utc)}`}))] : [el('option', {value: '', text: 'Планов пока нет'})]));
    sel.value = S.trip.report?.plan.id || '';
    for (const id of ['share-plan', 'download-plan', 'download-geojson', 'download-json']) $(id).disabled = !S.trip.report;
  }
  $('saved-plans').addEventListener('change', e => { if (e.target.value) openReport(e.target.value).then(renderTrip); else { S.trip.report = null; renderTrip(); } });
  async function openReport(id) {
    const run = ++runs.report;
    try { const r = await api('/api/scouting/plans/export?' + q({id})); if (run === runs.report) { S.trip.report = r; S.trip.focus = r.tasks[0]?.id || null; } }
    catch (e) { if (run === runs.report) { S.trip.report = null; toast(e.message + '. Откройте план из списка ещё раз.', {error: true}); } }
  }
  let tmap = null, tlayer = null;
  function renderTripMap() {
    if (!tmap) {
      tmap = L.map('trip-map', {zoomControl: true, attributionControl: true, minZoom: 10, maxZoom: 17});
      tmap.attributionControl.setPrefix(false);
      L.imageOverlay('/scouting/assets/wide-basemap.jpg', S.bundle.wide_basemap.bounds).addTo(tmap);
      L.imageOverlay('/scouting/assets/basemap.jpg', S.bundle.basemap.bounds, {attribution: 'Esri, Vantor, Earthstar Geographics'}).addTo(tmap);
      L.geoJSON(S.bundle.geometry, {style: {color: '#fff', weight: 1, fillOpacity: .04, opacity: .7}, interactive: false}).addTo(tmap);
      tlayer = L.layerGroup().addTo(tmap);
      new ResizeObserver(() => tmap.invalidateSize({pan: false})).observe($('trip-map'));
    }
    tlayer.clearLayers();
    const tasks = S.trip.report ? S.trip.report.tasks : S.trip.order.map(taskById).filter(Boolean);
    const pts = tasks.map(t => [t.payload.place.latitude, t.payload.place.longitude]);
    if (pts.length > 1) L.polyline(pts, {color: '#fff', weight: 3, dashArray: '8 8', opacity: .95}).addTo(tlayer);
    tasks.forEach((t, i) => {
      const st = classify({status: 'ready', ndvi: t.payload.evidence.metrics.ndvi, ndmi: t.payload.evidence.metrics.ndmi});
      const m = L.marker(pts[i], {icon: L.divIcon({className: '', html: `<div class="route-num rn-${st}">${i + 1}</div>`, iconSize: [34, 34], iconAnchor: [17, 17]}), title: `${i + 1}. ${t.payload.place.fragment}`});
      m.on('click', () => { S.trip.focus = t.id; renderChecklist(); });
      m.addTo(tlayer);
    });
    if (pts.length) tmap.fitBounds(L.latLngBounds(pts).pad(.6), {maxZoom: 15}); else tmap.fitBounds(L.geoJSON(S.bundle.geometry).getBounds());
    const chip = $('trip-map-chip').querySelector('span');
    chip.textContent = pts.length ? `${pts.length} ${plural(pts.length, 'место', 'места', 'мест')} • порядок задан вручную, дорога не рассчитана` + (S.trip.report ? ' • ' + S.trip.report.plan.payload.title : '') : 'Места не выбраны';
  }
  function renderChecklist() {
    const tasks = S.trip.report ? S.trip.report.tasks : S.trip.order.map(taskById).filter(Boolean);
    if (!tasks.find(t => t.id === S.trip.focus)) S.trip.focus = tasks[0]?.id || null;
    const t = taskById(S.trip.focus) || tasks.find(x => x.id === S.trip.focus);
    $('check-place').textContent = t ? '• ' + t.payload.place.fragment : '';
    for (const c of document.querySelectorAll('[data-check]')) if (c.dataset.for !== S.trip.focus) { c.checked = false; c.dataset.for = S.trip.focus || ''; }
    $('go-journal').disabled = !t;
  }
  $('go-journal').addEventListener('click', () => { S.visit.task = S.trip.focus; go('journal'); });
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
  function download(body, mime, ext) {
    const url = URL.createObjectURL(new Blob([body], {type: mime})), a = document.createElement('a');
    a.href = url; a.download = 'agropulse-plan-' + S.trip.report.plan.id.slice(0, 8) + '.' + ext; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000);
  }
  function sheetHtml() {
    const r = S.trip.report, p = r.plan.payload;
    const n = v => isNum(v) ? v.toFixed(3).replace('.', ',') : 'нет пригодных данных';
    const cards = r.tasks.map((t, i) => { const v = t.payload, e = v.evidence, m = v.place_evidence; return `<article><p class="eyebrow">${i + 1} / ${esc(v.place.fragment)} · ${esc(v.place.id)}</p><h2>${esc(v.objective)}</h2><p>${v.place.latitude.toFixed(6)}, ${v.place.longitude.toFixed(6)} · опора окна 60 м, не GPS</p><p>Ответственный: ${esc(v.actor)} · плановая дата: ${esc(v.planned_date || 'не назначена')}</p><table><tr><th>Архив</th><td>${esc(day(e.before.at))} → ${esc(day(e.after.at))} (${Math.round(e.days)} дн.)</td></tr><tr><th>ΔNDVI / ΔNDMI места</th><td>${n(m?.ndvi)} / ${n(m?.ndmi)}</td></tr><tr><th>ΔNDVI / ΔNDMI площади</th><td>${n(e.metrics.ndvi.base)} / ${n(e.metrics.ndmi.base)}</td></tr><tr><th>Покрытие</th><td>место ${m ? Math.round(m.coverage * 100) + '%' : '—'} · площадь ${Math.round(e.coverage * 100)}%</td></tr><tr><th>Фактический результат</th><td>□ Без замечаний □ Есть изменение □ Неясно □ Не удалось осмотреть<br><br>Наблюдения: ______________________________<br><br>Дата/время: ____________ Автор: ____________</td></tr></table></article>`; }).join('');
    const checks = p.site_checks.length ? '<h2>Что проверить перед монтажом</h2>' + p.site_checks.map(c => `<p>□ ${esc(c)} — пока не проверено</p>`).join('') : '';
    return `<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(p.title)}</title><style>body{font:15px/1.6 Montserrat,"Segoe UI",Arial,sans-serif;max-width:900px;margin:40px auto;padding:0 24px;color:#1E2B23}h1{font-size:28px;color:#1F4D2B}h2{font-size:18px;color:#1F4D2B}.eyebrow{font-size:12px;color:#5F6B66;font-weight:600}article{border-top:3px solid #198F51;padding:18px 0;margin:24px 0;break-inside:avoid}table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #DDE3DC;text-align:left;padding:8px;vertical-align:top}th{width:36%;font-weight:600}.note{color:#5F6B66;font-size:13px}@media print{body{margin:0;font-size:11px}}</style><p class="eyebrow">AGROPULSE / ONLYFARMS · ПЛАН ОСМОТРА</p><h1>${esc(p.title)}</h1><p>${esc(p.purpose_label)} · ${r.tasks.length} ${plural(r.tasks.length, 'место', 'места', 'мест')} · сохранён ${esc(dateTime(r.plan.recorded_at_utc))}</p><p class="note">${esc(r.notice)} Границы R01–R27 приблизительные. Пустые строки результата не являются осмотром.</p>${cards}${checks}</html>`;
  }
  function downloadSheet() { if (S.trip.report) download(sheetHtml(), 'text/html;charset=utf-8', 'html'); }
  $('download-plan').addEventListener('click', downloadSheet);
  $('download-json').addEventListener('click', () => { if (S.trip.report) download(JSON.stringify(S.trip.report, null, 2), 'application/json;charset=utf-8', 'json'); });
  $('download-geojson').addEventListener('click', () => {
    if (!S.trip.report) return;
    const features = S.trip.report.tasks.map((t, i) => { const p = t.payload; return {type: 'Feature', geometry: {type: 'Point', coordinates: [p.place.longitude, p.place.latitude]}, properties: {order: i + 1, place_id: p.place.id, task_id: t.id, objective: p.objective, before: p.evidence.before.at, after: p.evidence.after.at, confirmed_boundary: false, measured_gps: false, route_optimized: false}}; });
    download(JSON.stringify({type: 'FeatureCollection', features}, null, 2), 'application/geo+json;charset=utf-8', 'geojson');
  });
  $('share-plan').addEventListener('click', async () => {
    const r = S.trip.report; if (!r) return;
    const text = r.plan.payload.title + '\n' + r.tasks.map((t, i) => `${i + 1}. ${t.payload.place.fragment} (${t.payload.place.latitude.toFixed(5)}, ${t.payload.place.longitude.toFixed(5)}) — ${t.payload.objective}`).join('\n') + '\nКоординаты — опора окна 60 м, не GPS. Порядок задан вручную.';
    try {
      if (navigator.share) { await navigator.share({title: r.plan.payload.title, text}); return; }
      await navigator.clipboard.writeText(text); toast('Текст плана скопирован. Вставьте его в мессенджер или письмо.');
    } catch (e) { if (e.name !== 'AbortError') toast('Не удалось поделиться. Скачайте лист и отправьте файл.', {error: true}); }
  });

  // ================= JOURNAL =================
  for (const id of ['journal-search', 'f-area', 'f-days', 'f-outcome', 'f-actor']) $(id).addEventListener('input', renderJournalList);
  function renderJournal() {
    const areas = [...new Set((S.data.tasks || []).map(t => t.payload.place.fragment))].sort();
    const keepA = $('f-area').value, keepP = $('f-actor').value;
    $('f-area').replaceChildren(el('option', {value: '', text: 'Все поля'}), ...areas.map(a => el('option', {value: a, text: 'Площадь ' + a})));
    $('f-area').value = areas.includes(keepA) ? keepA : '';
    const actors = [...new Set((S.data.visits || []).map(v => v.payload.actor))].sort();
    $('f-actor').replaceChildren(el('option', {value: '', text: 'Все авторы'}), ...actors.map(a => el('option', {value: a, text: a})));
    $('f-actor').value = actors.includes(keepP) ? keepP : '';
    renderJournalList(); renderVisitForm();
  }
  function renderJournalList() {
    const list = $('journal-list'); list.replaceChildren();
    const tasks = new Map((S.data.tasks || []).map(t => [t.id, t]));
    const text = $('journal-search').value.trim().toLowerCase(), area = $('f-area').value, lim = $('f-days').value, outcome = $('f-outcome').value, actor = $('f-actor').value;
    const now = Date.now();
    const visits = (S.data.visits || []).filter(v => {
      const p = v.payload, t = tasks.get(p.task_id);
      if (area && p.place.fragment !== area) return false;
      if (lim && now - new Date(p.observed_at_utc).getTime() > Number(lim) * 864e5) return false;
      if (outcome && p.outcome !== outcome) return false;
      if (actor && p.actor !== actor) return false;
      if (text && ![p.place.fragment, p.place.id, p.notes, p.follow_up, t?.payload.objective].join(' ').toLowerCase().includes(text)) return false;
      return true;
    }).sort((a, b) => new Date(b.payload.observed_at_utc) - new Date(a.payload.observed_at_utc));
    let current = '';
    for (const v of visits) {
      const d = dayLong(v.payload.observed_at_utc);
      if (d !== current) { current = d; list.append(el('h2', {class: 'day-title', text: d})); }
      list.append(visitCard(v, tasks.get(v.payload.task_id)));
    }
    if (!visits.length) {
      const empty = el('div', {class: 'card empty-journal'}, icon('i-sprout'), el('div', {}, el('strong', {text: (S.data.visits || []).length ? 'Под фильтр записи не попали.' : 'Осмотров пока нет.'}), el('p', {text: (S.data.visits || []).length ? 'Измените поиск или фильтры.' : 'Первая запись появится после выезда. Здесь не бывает примерных или придуманных осмотров.'})));
      list.append(empty);
    }
    const pending = openTasks().filter(t => (!area || t.payload.place.fragment === area) && (!text || [t.payload.place.fragment, t.payload.place.id, t.payload.objective].join(' ').toLowerCase().includes(text)));
    if (pending.length) {
      list.append(el('h2', {class: 'day-title', text: 'Ждут результата'}));
      for (const t of pending) {
        const b = el('button', {type: 'button', class: 'btn btn-outline', text: 'Записать результат'});
        b.addEventListener('click', () => { S.visit.task = t.id; renderVisitForm(); $('visit-form').scrollIntoView({block: 'start'}); });
        list.append(el('div', {class: 'card task-pending'}, el('div', {}, el('h3', {text: 'Площадь ' + t.payload.place.fragment + ' • ' + t.payload.place.id}), el('p', {text: t.payload.objective}), el('p', {class: 'muted', text: 'Задача от ' + day(t.recorded_at_utc) + ' • ' + t.payload.actor})), b));
      }
    }
  }
  function visitCard(v, t) {
    const p = v.payload, o = OUTCOME[p.outcome];
    const photo = el('div', {class: 'visit-photo'});
    if (p.photos.length) photo.append(el('img', {src: `/api/scouting/visits/${v.id}/photos/${p.photos[0].id}`, alt: 'Фото осмотра: ' + p.photos[0].original_name, loading: 'lazy'}));
    else photo.append(icon('i-image'));
    const body = el('div', {},
      el('h3', {text: 'Площадь ' + p.place.fragment + ' • ' + p.place.id}),
      el('p', {class: 'who'}, icon('i-user'), dateTime(p.observed_at_utc) + ' • ' + p.actor + (p.retrospective_entry ? ' • внесено задним числом' : '')),
      el('p', {class: 'q', text: 'Вопрос: ' + (t?.payload.objective || '—')}),
      el('span', {class: 'status-badge ' + o.cls}, icon(o.icon), o.label),
      el('p', {class: 'comment'}, icon('i-comment'), p.notes),
      p.follow_up ? el('p', {class: 'comment'}, icon('i-arrow'), 'Следующий шаг: ' + p.follow_up) : null,
      p.photos.length > 1 ? el('p', {class: 'muted small', text: 'Фото: ' + p.photos.length}) : null);
    return el('article', {class: 'card visit-card'}, photo, body);
  }
  // visit form (unsaved result and photos stay in this page's memory only)
  function nowMoscow() {
    const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23'}).formatToParts(new Date()).map(x => [x.type, x.value]));
    return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}`;
  }
  function visitFields() { return {outcome: document.querySelector('[name=outcome]:checked')?.value || '', notes: $('visit-notes').value, follow: $('visit-follow').value, actor: $('visit-actor').value, time: $('visit-time').value, real: $('visit-real').checked, photos: S.visit.photos, request: S.visit.request}; }
  function stashVisit() { if (S.visit.shown) S.visit.drafts.set(S.visit.shown, visitFields()); }
  function renderVisitForm() {
    stashVisit();
    const tasks = (S.data.tasks || []).slice().reverse();
    const sel = $('visit-task');
    if (!tasks.length) {
      sel.replaceChildren(el('option', {value: '', text: 'Задач нет — форма открыта для просмотра'})); sel.disabled = true;
      $('entry-title').textContent = 'Новая запись • просмотр';
      $('visit-status').textContent = 'Сохранить результат можно после создания задачи на карте и реального посещения.';
    } else {
      sel.disabled = false;
      sel.replaceChildren(...tasks.map(t => el('option', {value: t.id, text: `${t.payload.place.fragment} • ${t.payload.objective.slice(0, 60)}${t.payload.objective.length > 60 ? '…' : ''}`})));
      if (!tasks.some(t => t.id === S.visit.task)) S.visit.task = openTasks()[0]?.id || tasks[0].id;
      sel.value = S.visit.task;
      $('entry-title').textContent = 'Новая запись';
    }
    S.visit.shown = sel.value || '';
    const d = S.visit.drafts.get(S.visit.shown);
    for (const r of document.querySelectorAll('[name=outcome]')) r.checked = d?.outcome === r.value;
    $('visit-notes').value = d?.notes || ''; $('visit-follow').value = d?.follow || ''; $('visit-actor').value = d?.actor || defaultActor();
    $('visit-time').value = d?.time || nowMoscow(); $('visit-time').max = nowMoscow(); $('visit-real').checked = !!d?.real;
    S.visit.photos = d?.photos || []; S.visit.request = d?.request || uid();
    renderPhotos(); visitReady(); loadPlaceHistory();
  }
  $('visit-task').addEventListener('change', e => { stashVisit(); S.visit.task = e.target.value; renderVisitForm(); });
  async function loadPlaceHistory() {
    const t = taskById(S.visit.task), box = $('place-history');
    if (!t) { box.hidden = true; return; }
    const run = ++runs.history, p = t.payload;
    const visits = (S.data.visits || []).filter(v => v.payload.place.id === p.place.id);
    box.hidden = false; box.replaceChildren(el('strong', {text: `История места ${p.place.id}`}), el('span', {class: 'muted', text: 'Загружаем ряд окна 60 м…'}));
    try {
      const h = await api('/api/scouting/history?' + q({place_id: p.place.id}));
      if (run !== runs.history) return;
      const rows = h.rows.filter(r => r.period === p.period).sort((a, b) => new Date(a.at) - new Date(b.at));
      const key = p.metric, ok = rows.filter(r => isNum(r[key]));
      box.replaceChildren(el('strong', {text: `История места ${p.place.id} • ${key.toUpperCase()} окна 60 м, ${PERIOD_LABEL[p.period]}`}));
      if (ok.length > 1) {
        const W = 480, H = 56, t0 = new Date(rows[0].at).getTime(), t1 = new Date(rows[rows.length - 1].at).getTime();
        const lo = Math.min(...ok.map(r => r[key])), hi = Math.max(...ok.map(r => r[key]));
        const x = tt => 4 + (tt - t0) / Math.max(1, t1 - t0) * (W - 8), y = v => 4 + (hi - v) / Math.max(1e-6, hi - lo) * (H - 8);
        const s = svgEl('svg', {class: 'spark', viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': `Ряд ${key.toUpperCase()} окна: ${ok.length} пригодных снимков из ${rows.length}`});
        let d = '', open = false;
        for (const r of rows) { if (isNum(r[key])) { d += (open ? 'L' : 'M') + x(new Date(r.at)).toFixed(1) + ' ' + y(r[key]).toFixed(1); open = true; } else open = false; }
        svgEl('path', {d}, s);
        for (const r of ok) svgEl('circle', {cx: x(new Date(r.at)), cy: y(r[key]), r: 2.5}, s);
        box.append(s);
      }
      box.append(el('span', {text: `Пригодных снимков окна: ${ok.length} из ${rows.length} • от ${num(Math.min(...ok.map(r => r[key])))} до ${num(Math.max(...ok.map(r => r[key])))} • осмотров места: ${visits.length}`}));
    } catch (e) { if (run === runs.history) box.replaceChildren(el('span', {class: 'muted', text: 'История места не загрузилась: ' + e.message})); }
  }
  function renderPhotos() {
    const box = $('photo-previews'); box.replaceChildren();
    S.visit.photos.forEach((ph, i) => {
      const rm = el('button', {type: 'button', 'aria-label': 'Убрать фото ' + ph.name}, icon('i-close'));
      rm.addEventListener('click', () => { URL.revokeObjectURL(ph.url); S.visit.photos.splice(i, 1); renderPhotos(); visitReady(); });
      box.append(el('figure', {}, el('img', {src: ph.url, alt: ph.name}), rm));
    });
    $('photo-drop').hidden = S.visit.photos.length >= 3;
  }
  $('visit-photos').addEventListener('change', async e => {
    for (const f of [...e.target.files]) {
      if (S.visit.photos.length >= 3) { toast('Можно приложить до трёх фотографий.', {error: true}); break; }
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) { toast(f.name + ': нужен JPEG, PNG или WebP.', {error: true}); continue; }
      if (f.size < 1 || f.size > 5_000_000) { toast(f.name + ': размер фото до 5 МБ.', {error: true}); continue; }
      S.visit.photos.push({name: f.name.slice(0, 200) || 'photo', file: f, url: URL.createObjectURL(f)});
    }
    e.target.value = ''; renderPhotos(); visitReady();
  });
  function visitReady() {
    const f = visitFields(), hasTask = !!taskById($('visit-task').value);
    const steps = [!!f.outcome, !!(f.photos.length || f.notes.trim()), !!f.notes.trim()];
    const first = steps.indexOf(false);
    document.querySelectorAll('.stepper li').forEach((li, i) => { li.classList.toggle('done', steps[i]); li.classList.toggle('active', i === (first < 0 ? 2 : first)); });
    const future = f.time && new Date(f.time + ':00+03:00').getTime() > Date.now();
    const ok = hasTask && f.outcome && f.notes.trim() && f.actor.trim() && f.time && !future && f.real && !S.visit.busy;
    $('save-visit').disabled = !ok;
    const missing = [!f.outcome && 'результат', !f.notes.trim() && 'наблюдения', !f.actor.trim() && 'автор', !f.time && 'время', !f.real && 'подтверждение посещения'].filter(Boolean);
    if (future) $('visit-status').textContent = 'Время осмотра не может быть в будущем.';
    else if (hasTask && !S.visit.busy && missing.length && (f.outcome || f.notes.trim())) $('visit-status').textContent = 'Для сохранения нужно: ' + missing.join(', ') + '.';
    else if (ok && /^Для сохранения/.test($('visit-status').textContent)) $('visit-status').textContent = '';
    const t = taskById($('visit-task').value), card = $('visit-preview-card'); card.replaceChildren();
    const ph = el('div', {class: 'visit-photo'}); if (f.photos[0]) ph.append(el('img', {src: f.photos[0].url, alt: ''})); else ph.append(icon('i-image'));
    const o = OUTCOME[f.outcome];
    card.append(el('div', {class: 'preview-card'}, ph, el('div', {}, el('strong', {text: t ? 'Площадь ' + t.payload.place.fragment : 'Площадь не выбрана'}), el('p', {class: 'muted small', text: (f.time ? f.time.replace('T', ' ') + ' МСК' : '—') + ' • ' + (f.actor.trim() || 'автор не указан')}),
      o ? el('span', {class: 'status-badge ' + o.cls}, icon(o.icon), o.label) : el('span', {class: 'muted small', text: 'Результат не выбран'}))));
    if (S.visit.shown) S.visit.drafts.set(S.visit.shown, f);
  }
  for (const id of ['visit-notes', 'visit-follow', 'visit-actor', 'visit-time', 'visit-real']) $(id).addEventListener('input', visitReady);
  for (const r of document.querySelectorAll('[name=outcome]')) r.addEventListener('change', visitReady);
  $('visit-reset').addEventListener('click', () => { S.visit.photos.forEach(p => URL.revokeObjectURL(p.url)); S.visit.drafts.delete(S.visit.shown); S.visit.shown = ''; renderVisitForm(); });
  const toBase64 = file => new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result).split(',')[1]); r.onerror = () => reject(new Error('Не удалось прочитать фото')); r.readAsDataURL(file); });
  $('visit-form').addEventListener('submit', async e => {
    e.preventDefault(); if ($('save-visit').disabled || S.visit.busy) return;
    const f = visitFields();
    S.visit.busy = true; visitReady(); $('visit-status').classList.remove('error'); $('visit-status').textContent = 'Сохраняем запись осмотра…';
    try {
      const photos = [];
      for (const ph of f.photos) photos.push({filename: ph.name, data_base64: await toBase64(ph.file)});
      await api('/api/scouting/visits', {request_id: f.request, task_id: $('visit-task').value, actor: f.actor.trim(), observed_at: f.time + ':00+03:00', notes: f.notes.trim(), outcome: f.outcome, follow_up: f.follow.trim(), photos, real_visit_confirmed: true});
      f.photos.forEach(p => URL.revokeObjectURL(p.url));
      S.visit.drafts.delete(S.visit.shown); S.visit.shown = '';
      await refreshState(); renderJournal();
      $('visit-status').textContent = 'Запись осмотра сохранена в журнал.';
      toast('Результат осмотра записан.');
    } catch (err) { $('visit-status').classList.add('error'); $('visit-status').textContent = err.message; }
    finally { S.visit.busy = false; visitReady(); }
  });

  // ================= boot =================
  try {
    const [data, bundle] = await Promise.all([api('/api/scouting/state'), api('/scouting/assets/public-context.json')]);
    S.data = data; S.bundle = bundle;
    if (!S.bundle.features[S.fid]) S.fid = Object.keys(S.bundle.features).sort()[0];
    renderAvatar(); renderActors(); fillActorDefaults(); renderLegend();
    $('loading').hidden = true;
    window.addEventListener('hashchange', route);
    route();
  } catch (error) {
    $('loading').hidden = true; $('fatal').hidden = false;
    $('fatal').textContent = 'Не удалось открыть архив: ' + error.message + '. Данные не подменены. Проверьте, что сервер AgroPulse запущен, и обновите страницу.';
  }
})();
